//Brianna McCollum Milestone Arcade
#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h> // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Arcade With Lights - Brianna McCollum"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbos[2];     // Handles for the vertex buffer objects
        GLuint nIndices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Triangle mesh data
    GLMesh gMesh;
    //More mesh data for my pyramid. Still triangular though!
    GLMesh gPyramidMesh;
    //Even more mesh data for our plane!
    GLMesh gPlaneMesh;
    // Shader program
    //base lighting
    GLuint gProgramId;
    //No lighting for "glowing" screen
    GLuint gScreenId;

    //camera variables
    //I wanted to start a bit further back so I changed to start at 5
    Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
    //We can't use the camera class to change up and down, so we'll adjust the camera with a vector
    glm::vec3 gCameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    //variables for timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;
    float timeDelay = 0.0f; //used by mouse wheel to slow or speed time

    //Global variable for toggling between Perspective and Orthographic
    bool isOrtho = false;


    //For now I'll be hard-setting the shape's color since I don't have textures working
    //It'll be blue with some other hues for the lights
    glm::vec3 gObjectColor(0.3f, 0.1f, 1.0f);
    //And red for the joystick so it stands out for now
    glm::vec3 gJoystickColor(1.0f, 0.1f, 0.25f);
    //And then blue-ishgrey for the background walls
    glm::vec3 gWallColor(0.5f, 0.5f, 0.75f);
    
    //These are vec4's because they're for the shader that doesn't factor in lighting
    //bright white for the screen
    glm::vec4 gScreenColor(1.0f, 1.0f, 1.0f, 1.0f);
    //and neon blue for the strip light
    glm::vec4 gStripColor(0.0f, 0.8f, 1.0f, 1.0f);

    //white light for the screen
    glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);
    //Ambient light of the arcade is blueish
    glm::vec3 gKeyLightColor(0.8f, 0.75f, 1.0f);

    // Light positions
    glm::vec3 gFillLightPosition(1.0f, 1.5f, 1.0f);

    //blue light is the strip of lights up top
    glm::vec3 gKeyLightPosition(1.0f, 2.0f, 1.0f);
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh);
//Different mesh creator object for my different primitive object. Probably a really bootleg work-around
void UCreatePyramidMesh(GLMesh& mesh);
//Another mesh creator for my plane objects
void UCreatePlaneMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
//Mouse related functions
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);


/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal;  // Normals from Vertex Attrib Pointer 1

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader

//Global variables for the transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
}
);


/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
//Two light color and position variables for the different light sources
uniform vec3 objectColor;
uniform vec3 fillLightColor;
uniform vec3 keyLightColor;
uniform vec3 fillLightPos;
uniform vec3 keyLightPos;
uniform vec3 viewPosition;

void main()
{
    //We're going to calculate both the screen lights and the accent pink lights and add them to the finalPhong, which will then be sent to the GPU
    vec3 finalPhong = vec3(0.0);

    //-----Screen Light-----
     /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.25f; // Set ambient or global lighting strength
    vec3 ambient = ambientStrength * fillLightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(fillLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * fillLightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.8f; // Set specular light strength
    float highlightSize = 8.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * fillLightColor;

    // Calculate phong result
    //Tone down the intensity just a hair
    vec3 phong = ((ambient + diffuse + specular) * objectColor) * 0.8;

    //add to output
    finalPhong += phong;


    //-----Accent Light-----
     /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    ambient = ambientStrength * keyLightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    lightDirection = normalize(keyLightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    diffuse = impact * keyLightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    specular = specularIntensity * specularComponent * keyLightColor;

    // Calculate phong result
    ////the blue light isn't the focal point, so let's reduce its intensity
    phong = ((ambient + diffuse + specular) * objectColor) * 0.25;

    //add to output
    finalPhong += phong;


    fragmentColor = vec4(finalPhong, 1.0f); // Send lighting results to GPU
}
);

//----- Screen Shader Source Code -----
const GLchar* screenVertexShaderSource = GLSL(440,

    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* screenFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor; // For outgoing screen color to the GPU
    
    //Uniform / Global variables for the object color
    uniform vec4 objectColor;

void main()
{
    fragmentColor = objectColor;
}
);



int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object
    UCreatePyramidMesh(gPyramidMesh); // Create the Vertex Buffer Object for pyramids too
    UCreatePlaneMesh(gPlaneMesh); // Create the Vertex Buffer Object for planes

    // Create the shader programs
    //For reference: Phong lighting calculations are in the fragment shader! Don't forget Brianna!
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(screenVertexShaderSource, screenFragmentShaderSource, gScreenId))
        return EXIT_FAILURE;

    // Sets the background color of the window to black (it will be implicitely used by glClear)
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        //Keeps track of our timing variables in the rendering loop
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gMesh);
    UDestroyMesh(gPyramidMesh);
    UDestroyMesh(gPlaneMesh);

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gScreenId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    //Initialize the mouse functions within initialize
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    static const float cameraSpeed = 2.5f;
    float cameraOffset = cameraSpeed * gDeltaTime;

    //Move camera forward
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    //Move camera Backwards
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    //Move camera left
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    //Move camera right
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    //gCamera doesn't have built in functions for up or down
    //I'm not sure if it was more proper to adjust Camera class itself, usually changing an import is wrong so I didn't
    //I decided to access the Position vector directly
    //Move camera straight up
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.Position += cameraOffset * gCameraUp;
    //Move camera straight down
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.Position -= cameraOffset * gCameraUp;

    //Toggle between Perspective and Orthographic display
    //GLFW_PRESS is really touchy. Is there a better way to do this? 
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
        if (isOrtho) {
            isOrtho = false;
        }
        else {
            isOrtho = true;
        }
    }
}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}


// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    //I'm accessing a variable from the Camera class directly to change the movement speed
    //Scrolling forwards speeds it up
    if (yoffset > 0) {
        gCamera.MovementSpeed += .1f;
        cout << "Camera sped up to " << gCamera.MovementSpeed << endl;
    }
    //Scrolling backwards slows it down
    else if (yoffset < 0) {
        //Special case handler: if we go under 0.0f movement speed, the camera will go in the opposite direction
        //We also don't want to lower the speed lower than .1f so it's still moving
        //we're actually comparing .2f because floats are innacurate and weird. It'll keep the camera always moving
        if (gCamera.MovementSpeed <= 0.2f) {
            //Do nothing
        }
        else {
            gCamera.MovementSpeed -= .1f;
            cout << "Camera slowed down to " << gCamera.MovementSpeed << endl;
        }
    }

}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //---Draw Main Body of Machine---

    //Below is the model matrix, which uses matrix mathematics to put us in world space
    // 1. Scales the object by 2, by 3.7 for y so it's taller
    glm::mat4 scale = glm::scale(glm::vec3(2.0f, 3.7f, 2.0f));
    // 2. Rotates shape by 15 degrees in the y axis
    glm::mat4 rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place machine to the left of the scene by reducing x. 
    //We also want to make sure it doesn't go off the top, so we shift it down in the y direction
    glm::mat4 translation = glm::translate(glm::vec3(-1.0f, -1.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    glm::mat4 model = translation * rotation * scale;

    // camera/view transformation
    //We use the camera class to manage this
    glm::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    //It is innitialized to perspective by default, as this is the default view of our program
    glm::mat4 projection = glm::perspective(45.0f, (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);

    if (isOrtho) {
        // Change it to an orthographic projection if isOrtho is true
        projection = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
    }

    // Set the shader to be used
    //Reminder: Change this for the screen! <------
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    GLint modelLoc = glGetUniformLocation(gProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gProgramId, "view");
    GLint projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // References for the Lights
    GLint objectColorLoc = glGetUniformLocation(gProgramId, "objectColor");
    //Two different lights, so two light colors and positions
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "fillLightColor");
    GLint keyLightColorLoc = glGetUniformLocation(gProgramId, "keyLightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "fillLightPos");
    GLint keyLightPositionLoc = glGetUniformLocation(gProgramId, "keyLightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    //Camera position only needs defined once, right here
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //--- Draw Screen ---

    //get the shader for the screen
    glUseProgram(gScreenId);

    // 1. Keep it the same size, but scale the x so it pokes out of the machine
    scale = glm::scale(glm::vec3(1.75f, 1.0f, 1.0f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Make the screen stick out just barely from the front of the arcade machine by shifting it forward and a bit left with z and x
    //also shift it up just slgihtly
    translation = glm::translate(glm::vec3(-1.0f, 0.5f, 0.25f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Reference matrix uniforms from the Screen Shader program
    modelLoc = glGetUniformLocation(gScreenId, "model");
    viewLoc = glGetUniformLocation(gScreenId, "view");
    projLoc = glGetUniformLocation(gScreenId, "projection");

    // Pass matrix data to the Screen Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    //Connects to the right global variable in the shader then sends the color variable to the lightless shader
    GLint screenObjectColorLoc = glGetUniformLocation(gScreenId, "objectColor");
    glUniform4f(screenObjectColorLoc, gScreenColor.r, gScreenColor.g, gScreenColor.b, gScreenColor.a);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //--- Draw Blue Lights ---

    //stay on the screen shader

    //Squish it in the x so it can fit in the small spot on the beneath of the roof
    scale = glm::scale(glm::vec3(0.25f, 0.25f, 1.5f));
    // 2. Rotates shape by 15 degrees in the y axis
    //Also rotate it slightly on the x to get it diagonal
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotation2 = glm::rotate(25.0f, glm::vec3(0.0f, 0.0f, 1.0f));
    // 3. Place top to the left of the scene by reducing x
    //also bring it forward a bit so that it appears to stick out of the main body
    translation = glm::translate(glm::vec3(-0.15f, 1.75f, 0.85f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * rotation2 * scale;

    // Reference matrix uniforms from the Screen Shader program
    modelLoc = glGetUniformLocation(gScreenId, "model");
    viewLoc = glGetUniformLocation(gScreenId, "view");
    projLoc = glGetUniformLocation(gScreenId, "projection");

    // Pass matrix data to the Screen Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    //sends the color variable to the lightless shader
    glUniform4f(screenObjectColorLoc, gStripColor.r, gStripColor.g, gStripColor.b, gStripColor.a);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //---Draw Left Joystick Stub---

    //make sure to reset to normal shader!

   // 1. Joystick is pretty small, so let's scale it down
    //We also want it pretty slender, so keep the y slightly bigger
    scale = glm::scale(glm::vec3(0.25f, 0.5f, 0.25f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place joystick pyramid on the console object
    translation = glm::translate(glm::vec3(-0.4f, -0.5f, 2.15f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPyramidMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    //Uses a different color here for the joystick
    glUniform3f(objectColorLoc, gJoystickColor.r, gJoystickColor.g, gJoystickColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPyramidMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //---Draw Right Joystick Stub---

    // 1. Joystick is pretty small, so let's scale it down
     //We also want it pretty slender, so keep the y slightly bigger
    scale = glm::scale(glm::vec3(0.25f, 0.5f, 0.25f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place joystick pyramid on the console object
    //Place it a bit more to the right than the other
    translation = glm::translate(glm::vec3(0.5f, -0.5f, 1.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPyramidMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    //Uses a different color here for the joystick
    glUniform3f(objectColorLoc, gJoystickColor.r, gJoystickColor.g, gJoystickColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPyramidMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //---Draw Right Side Bar---

    // 1. Scales the object to be small and slender, by 3.7 for y so it's taller
    scale = glm::scale(glm::vec3(0.5f, 3.7f, 0.25f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place side bar on the right of the machine by adding a small bit to x 
    //We also want to make sure it doesn't go off the top, so we shift it down in the y direction
    translation = glm::translate(glm::vec3(0.5f, -1.0f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object
    glBindVertexArray(0);


    //---Draw Left Side Bar---

    //Pretty much the same as the right side bar, just transformed to the left of the machine instead of the right
    scale = glm::scale(glm::vec3(0.5f, 3.7f, 0.25f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place side bar on the right of the machine by adding a small bit to x 
    //We also want to make sure it doesn't go off the top, so we shift it down in the y direction
    translation = glm::translate(glm::vec3(-1.25f, -1.0f, 2.1f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and the shader program
    glBindVertexArray(0);


    //---Draw Background Wall Plane---

    // 1. Gotta be pretty big to cover background, so scale it up huge
    scale = glm::scale(glm::vec3(10.0f, 10.0f, 10.0f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Move the plane behind the arcade console so it looks like a wall
    translation = glm::translate(glm::vec3(0.0f, 0.0f, -2.5f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    //different color variable for the wall
    glUniform3f(objectColorLoc, gWallColor.r, gWallColor.g, gWallColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and the shader program
    glBindVertexArray(0);


    //---Draw Background Floor Plane---

    // 1. Gotta be pretty big to cover background, so scale it up huge
    scale = glm::scale(glm::vec3(10.0f, 10.0f, 10.0f));
    // 2. Rotates shape by 15 degrees in the y axis
    //Then Rotate it by 29.85 in the z to get it flat
    //I have no idea why this specific decimal number gets it flat. It was a lot of trial and error
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    rotation2 = glm::rotate(29.85f, glm::vec3(0.0f, 0.0f, 1.0f));
    // 3. Move the plane below the arcade console so it looks like a floor
    //Also pull it forward a bit so it creates more floorspace
    translation = glm::translate(glm::vec3(2.0f, -2.75f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * rotation2 * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gPlaneMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    //different color variable for the wall
    glUniform3f(objectColorLoc, gWallColor.r, gWallColor.g, gWallColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gPlaneMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and the shader program
    glBindVertexArray(0);


    //---Draw Arcade Top---

    // 1. Scale the object's z by 2.1, x by 2.5 and y by .5
    //We want it to be quite long so that it sticks out from the console
    scale = glm::scale(glm::vec3(2.85f, 0.5f, 2.1f));
    // 2. Rotates shape by 15 degrees in the y axis
    //Also rotate it slightly on the x to get it diagonal
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    rotation2 = glm::rotate(25.0f, glm::vec3(0.0f, 0.0f, 1.0f));
    // 3. Place top to the left of the scene by reducing x
    //also bring it forward a bit so that it appears to stick out of the main body
    translation = glm::translate(glm::vec3(-0.9f, 1.75f, 0.0f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * rotation2 * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and the shader program
    glBindVertexArray(0);


    //---Draw Arcade console---

    // 1. Scale the object's z by 2, x by 2 and y by .5, we want it to be shorter but not smaller
    scale = glm::scale(glm::vec3(2.0f, 0.5f, 2.0f));
    // 2. Rotates shape by 15 degrees in the y axis
    rotation = glm::rotate(15.0f, glm::vec3(0.0f, 1.0f, 0.0f));
    // 3. Place console to the left of the scene by reducing x
    //also bring it forward a bit so that it appears to stick out of the main body
    translation = glm::translate(glm::vec3(0.0f, -1.0f, 0.85f));
    // Model matrix: transformations are applied right-to-left order
    model = translation * rotation * scale;

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the Shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Activate the VBOs contained within the mesh's VAO
    glBindVertexArray(gMesh.vao);

    // Pass color, light, and camera data to the Pyramid's Shader program's corresponding uniforms
    glUniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    glUniform3f(lightColorLoc, gLightColor.r, gLightColor.g, gLightColor.b);
    glUniform3f(keyLightColorLoc, gKeyLightColor.r, gKeyLightColor.g, gKeyLightColor.b);
    glUniform3f(lightPositionLoc, gFillLightPosition.x, gFillLightPosition.y, gFillLightPosition.z);
    glUniform3f(keyLightPositionLoc, gKeyLightPosition.x, gKeyLightPosition.y, gKeyLightPosition.z);
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    // Draws the triangles
    glDrawElements(GL_TRIANGLES, gMesh.nIndices, GL_UNSIGNED_SHORT, NULL); // Draws the triangle

    // Deactivate the Vertex Array Object and the shader program
    glBindVertexArray(0);
    glUseProgram(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    //-----Position and Color data-----
    GLfloat verts[] = {
        // Vertex Positions    // Normals (for calcing light)
         0.5f,  0.75f, 0.5f,   1.0f,  0.0f,  0.0f, // Top Right Vertex 0
         0.5f, -0.5f, 0.5f,   1.0f,  0.0f,  0.0f, // Bottom Right Vertex 1
        -0.5f, -0.5f, 0.5f,   0.0f,  0.0f,  1.0f, // Bottom Left Vertex 2
        -0.5f,  0.75f, 0.5f,   0.0f,  0.0f,  1.0f, // Top Left Vertex 3

         0.5f, -0.5f, -1.0f,  0.0f,  0.0f, -1.0f, // 4 br  right
         0.5f,  0.75f, -1.0f,  0.0f,  0.0f, -1.0f, //  5 tr  right
        -0.5f,  0.75f, -1.0f,  -1.0f,  0.0f,  0.0f, //  6 tl  top
        -0.5f, -0.5f, -1.0f,  -1.0f,  0.0f,  0.0f //  7 bl top
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 3,  // Triangle 1
        1, 2, 3,   // Triangle 2
        0, 1, 4,  // Triangle 3
        0, 4, 5,  // Triangle 4
        0, 5, 6, // Triangle 5
        0, 3, 6,  // Triangle 6
        4, 5, 6, // Triangle 7
        4, 6, 7, // Triangle 8
        2, 3, 6, // Triangle 9
        2, 6, 7, // Triangle 10
        1, 4, 7, // Triangle 11
        1, 2, 7 // Triangle 12
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
}


//Alternative UCreateMesh for Plane objects
void UCreatePlaneMesh(GLMesh& mesh)
{
    //-----Position and Color data-----
    GLfloat verts[] = {
        // Vertex Positions    // Normals
        //Normals are all facing forwards since a flat plane only has one normal
         0.0f, -0.5f, 1.0f,  1.0f,  0.0f,  0.0f, // 0 bottom right
         0.0f,  0.5f, 1.0f,  1.0f,  0.0f,  0.0f, //  1 top  right
         0.0f,  0.5f, -1.0f,  1.0f,  0.0f,  0.0f, //  2 top  left
         0.0f, -0.5f, -1.0f,  1.0f,  0.0f,  0.0f, //  3 bottom left
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 3,  // Triangle 1
        1, 2, 3   // Triangle 2
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerNormal = 3;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
}


// Alternative UCreateMesh for Pyramid objects
//There is probably a much better way to go about this in OpenGL implementation, but I couldn't find it myself
void UCreatePyramidMesh(GLMesh& mesh)
{
    // Position and Color data
    GLfloat verts[] = {
        // Vertex Positions    // Normals (for calcing light)
        //---------------------------------------------------
        0.0f,  0.5f, 0.0f,       0.0f,  1.0f,  0.0f, // 0 - Top point (will get used a lot by indicies)

         0.5f,  -0.5f, 0.5f,     1.0f,  0.0f,  0.0f, // 1 - Front Right
         0.5f, -0.5f, -0.5f,     0.0f,  0.0f,  -1.0f, // 2 - Back Right
        -0.5f, -0.5f, -0.5f,     0.0f,  0.0f,  -1.0f, // 3 - Back Left
         -0.5f,  -0.5f, 0.5f,    1.0f,  0.0f,  0.0f  // 4 - Front Left
    };

    // Index data to share position data
    GLushort indices[] = {
        0, 1, 2,  // Triangle 1
        0, 2, 3,   // Triangle 2
        0, 3, 4,  // Triangle 3
        0, 1, 4,  // Triangle 4
        1, 2, 4, // Triangle 5
        2, 3, 4,  // Triangle 6
    };

    const GLuint floatsPerVertex = 3;
    //replacing floats per color with floats per normal so we can do light
    const GLuint floatsPerNormal = 3;

    glGenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    glBindVertexArray(mesh.vao);

    // Create 2 buffers: first one for the vertex data; second one for the indices
    glGenBuffers(2, mesh.vbos);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbos[0]); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW); // Sends vertex or coordinate data to the GPU

    mesh.nIndices = sizeof(indices) / sizeof(indices[0]);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh.vbos[1]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    //The exact stride is different now that we're using normals (3 instead of 4 points), but the idea is the same
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal);// The number of floats before each

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);
}



void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(2, mesh.vbos);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}